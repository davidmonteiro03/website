from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
import json
from .models import Users
from rest_framework_simplejwt.tokens import RefreshToken
# import Q operator for complex queries
from django.db.models import Q
from . import parse
from django.views.decorators.http import require_POST

# Create your views here
@require_POST
def signup(request):
	# Users.objects.all().delete()
	try:
		data = json.loads(request.body)
		parsing = {
			'fname': parse.name(data['fname']),
			'lname': parse.name(data['lname']),
			'username': parse.username(data['username']),
			'email': parse.email(data['email']),
			'password': parse.password(data['password'])
		}
		if not all(parsing.values()):
			return JsonResponse(None, safe=False, status=401)
		target = Users.objects.filter(
			Q(username=parsing['username']) | Q(email=parsing['email'])
		).first()
		if target:
			return JsonResponse(None, safe=False, status=401)
		user = Users.objects.create(username=parsing['username'])
		return JsonResponse({'token': str(RefreshToken.for_user(user))})
	except:
		return JsonResponse(None, safe=False, status=400)

# def update(request):
# 	if (request.method != 'POST'):
# 		return redirect('/')
# 	if not request.body or request.body == b'{}':
# 		return JsonResponse(None, safe=False, status=400)
# 	in_data = json.loads(request.body)
# 	target = Users.objects.filter(
# 		username=in_data['user_data']['username'],
# 		email=in_data['user_data']['email']
# 	).first()
# 	if not target:
# 		return JsonResponse(None, safe=False, status=400)
# 	values = {
# 		'fname': parse.name(in_data['new_data']['fname']),
# 		'lname': parse.name(in_data['new_data']['lname']),
# 		'username': parse.username(in_data['new_data']['username']),
# 		'email': parse.email(in_data['new_data']['email']),
# 	}
# 	target = Users.objects.filter(
# 		username=in_data['user_data']['username'],
# 		email=in_data['user_data']['email']
# 	).first()
# 	for key in in_data['new_data']:
# 		if values[key] and values[key] != target.__dict__[key]:
# 			target.__dict__[key] = values[key]
# 	target.save()
# 	out_data = {
# 		'fname': target.fname,
# 		'lname': target.lname,
# 		'username': target.username,
# 		'email': target.email
# 	}
# 	return JsonResponse(out_data)
