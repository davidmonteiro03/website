import http
from django.shortcuts import render
from django.http import HttpResponse

class CustomErrorHandlerMiddleware:
	def __init__(self, get_response):
		self.get_response = get_response

	def __call__(self, request):
		try:
			response = self.get_response(request)
			if response.status_code == 200:
				return response
			return HttpResponse(
				render(
					request, "error.html", context={
						'status_code': response.status_code,
						'error': http.HTTPStatus(response.status_code).phrase
					}
				).content, status=response.status_code
			)
		except Exception as e:
			return HttpResponse("Internal Server Error")
