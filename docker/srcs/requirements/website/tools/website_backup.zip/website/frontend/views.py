from django.http import JsonResponse
from django.shortcuts import render
from django.template import loader
import json
from django.views.decorators.http import require_POST

# Create your views here.

@require_POST
def change_page(request, page):
	html = {'html': loader.render_to_string(f'{page}.html')}
	if request.body == None or request.body == b'':
		return JsonResponse(html)
	data = json.loads(request.body)
	html = {'html': loader.render_to_string(f'{page}.html', data)}
	return JsonResponse(html)

def body(request):
	return render(request, 'body.html')

@require_POST
def navbar(request):
	return change_page(request, 'navbar')

@require_POST
def modal(request):
	return change_page(request, 'modal')

@require_POST
def index(request):
	return change_page(request, 'index')

@require_POST
def profilepage(request):
	return change_page(request, 'profilepage')
